import java.util.Stack;

public class Palindromo {

    public boolean verificarPalindromo(String palavra) {

        String palavraLimpa = palavra.replaceAll("[^a-zA-Z0-9]", "").toLowerCase();

        Stack<Character> pilha = new Stack<>();

        for (char c : palavraLimpa.toCharArray()) {
            pilha.push(c);
        }

        StringBuilder invertida = new StringBuilder();

        while (!pilha.isEmpty()) {
            invertida.append(pilha.pop());
        }

        return palavraLimpa.equals(invertida.toString());
    }

    public static void main(String[] args) {
        Palindromo p = new Palindromo();

        String[] testes = {"arara", "Ana", "Amor", "A man, a plan, a canal: Panama"};

        for (String teste : testes) {
            System.out.println("A palavra '" + teste + "' é palíndromo? " + p.verificarPalindromo(teste));
        }
    }
}
